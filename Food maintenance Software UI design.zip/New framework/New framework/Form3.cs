﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace New_framework
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Start();
            loadbar.Width = 1;
        }

        private void loadbar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                loadbar.Width += 20;
                if(loadbar.Width == 261)
                {
                    timer1.Stop();
                    Form1 fff = new Form1();
                    fff.Show();
                    this.Hide();
                }
            }
            catch(Exception)
            {
                return;
            }
        }
    }
}

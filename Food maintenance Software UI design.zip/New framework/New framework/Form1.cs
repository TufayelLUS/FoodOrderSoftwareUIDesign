﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace New_framework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            f4.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            f.Focus();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            indicator.Left = 0;
            indicator.Top = button4.Top;
            headlinetxt.Text = "Who we are?";
            contentbx.Items.Clear();
            contentbx.Items.Add("Hello world, This is UI practice");
            contentbx.Items.Add("Some line goes here");
            contentbx.Items.Add("Some more line here");
            contentbx.Items.Add("Some more here");
            contentbx.Items.Add("- by Tufayel Ahmed");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            indicator.Left = 0;
            indicator.Top = button5.Top;
            headlinetxt.Text = "Food Menu";
            contentbx.Items.Clear();
            contentbx.Items.Add("Food menu content goes here");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            indicator.Left = 0;
            indicator.Top = button6.Top;
            headlinetxt.Text = "My Profile";
            contentbx.Items.Clear();
            contentbx.Items.Add("My profile content goes here");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            indicator.Left = 0;
            indicator.Top = button7.Top;
            headlinetxt.Text = "Contact Us";
            contentbx.Items.Clear();
            contentbx.Items.Add("Write to us on chefhouseadmin@localhost.localdomain");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            indicator.Left = 0;
            indicator.Top = button8.Top;
            headlinetxt.Text = "About Us";
            contentbx.Items.Clear();
            contentbx.Items.Add("Program designed for maintaining Food Orders Online");
            contentbx.Items.Add("UI by Tufayel Ahmed");
        }

        private void contentbx_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
